(() => {
  "use strict";
  const menuButton = document.querySelector(".menu-toggle");
  const navLinks = document.querySelector(".nav-links");
  if (menuButton && navLinks) {
    menuButton.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("open");
      menuButton.setAttribute("aria-expanded", String(isOpen));
      menuButton.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
    });
    navLinks.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
      navLinks.classList.remove("open");
      menuButton.setAttribute("aria-expanded", "false");
    }));
  }

  const revealItems = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealItems.forEach(item => observer.observe(item));
  } else {
    revealItems.forEach(item => item.classList.add("is-visible"));
  }

  const backTop = document.querySelector(".back-top");
  const updateBackTop = () => backTop?.classList.toggle("visible", window.scrollY > 500);
  window.addEventListener("scroll", updateBackTop, { passive: true });
  updateBackTop();

  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  const form = document.getElementById("lead-form");
  const status = document.getElementById("form-status");
  const submit = form?.querySelector('button[type="submit"]');
  if (form) {
    form.addEventListener("submit", async event => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const data = new FormData(form);
      const name = String(data.get("name") || "").trim();
      const message = String(data.get("message") || "").trim();
      if (name.length < 2 || message.length < 10) {
        status.textContent = "Please add a valid name and a little more detail about your project.";
        status.classList.add("form-error");
        return;
      }
      if (data.get("bot-field")) return;
      submit.disabled = true;
      submit.querySelector(".submit-label").textContent = "Sending enquiry…";
      status.classList.remove("form-error");
      try {
        // Netlify Forms receives submissions automatically after deployment on Netlify.
        const response = await fetch("/", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams(data).toString()
        });
        if (!response.ok) throw new Error("Form submission failed");
        form.reset();
        status.textContent = "Thanks — your enquiry has been sent. The GreenNovex team will be in touch.";
        status.classList.add("form-success");
      } catch (error) {
        status.textContent = "The form could not be sent from this preview. Please contact @gnx.creative on Instagram, or deploy this site on Netlify to activate form delivery.";
        status.classList.add("form-error");
      } finally {
        submit.disabled = false;
        submit.querySelector(".submit-label").textContent = "Send project enquiry";
      }
    });
  }
})();