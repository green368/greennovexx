# GreenNovex — Agency Website

A responsive, dark-mode agency landing page built with HTML5, Tailwind CSS CDN, custom CSS, and vanilla JavaScript.

## Files
- `index.html` — page structure, SEO metadata, service sections, and Netlify lead form
- `style.css` — responsive design system, layouts, motion, and visual styling
- `script.js` — mobile navigation, reveal-on-scroll, back-to-top, and validated form submission
- `assets/` — reserved for local brand assets

## Deploy to Netlify
1. Unzip the project.
2. Drag the `greennovex-agency` folder into Netlify Drop, or connect its Git repository.
3. Netlify detects the `data-netlify="true"` form. After deployment, submit one test enquiry and verify it under **Forms** in the Netlify dashboard.
4. In Netlify, enable form notifications if you want enquiries emailed to you.

The contact form uses Netlify Forms and is active after deployment to Netlify. On GitHub Pages, static HTML cannot securely receive/store form submissions by itself; connect a form provider or an n8n webhook before using the form there.

## Connect n8n (optional)
For an n8n-backed lead pipeline, use a Webhook node configured for `POST` and connect it to your CRM, Google Sheets, Telegram, or email workflow. Then replace the Netlify `fetch("/")` request in `script.js` with a `fetch("YOUR_N8N_WEBHOOK_URL", { method: "POST", body: JSON.stringify(Object.fromEntries(data)), headers: { "Content-Type": "application/json" } })` request. Add appropriate CORS settings in n8n and use HTTPS. Do not put API secrets in browser JavaScript.

## Notes
- Tailwind is loaded from its CDN, and Google Fonts are loaded remotely; an internet connection is required for those external assets.
- All visual artwork in the hero and service cards is CSS-based; no stock-image dependencies.
- Replace or extend the service copy and budget ranges as your actual offers evolve.
